<?php
    return array('name'=>'CompManager',
                 'namespace'=>'CompManager',
                 'factory'=>'Factory',
                 'author'=>'Max',
                 'version'=>'1.0');
?>