<?php
    namespace HTMLMapper;

    class DataObject{
        
    }
?>
