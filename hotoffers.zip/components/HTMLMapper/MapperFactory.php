<?php
    namespace HTMLMapper;

    class MapperFactory implements DataFactory{
        
    }
?>
