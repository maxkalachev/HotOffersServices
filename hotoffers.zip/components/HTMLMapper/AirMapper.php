<?php
    namespace HTMLMapper;

    class AirMapper extends DataMapper{
        
    }
?>
