<?php
    namespace HTMLMapper;

    interface DataFactory{
        public function create();
    }
?>
