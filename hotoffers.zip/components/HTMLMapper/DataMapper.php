<?php
    namespace HTMLMapper;

    class DataMapper{
        
    }
?>
