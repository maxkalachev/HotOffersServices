<?php
    namespace HTMLMapper;

    class ObjectFactory implements DataFactory{
        
    }
?>
