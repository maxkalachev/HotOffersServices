<?php
    return array('name'=>'HTMLMapper',
                 'namespace'=>'HTMLMapper',
                 'factory'=>'Factory',
                 'author'=>'Max',
                 'version'=>'1.0');
?>