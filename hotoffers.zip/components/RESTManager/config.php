<?php
    return array('name'=>'RESTManager',
                 'namespace'=>'RESTManager',
                 'factory'=>'RESTManagerFactory',
                 'author'=>'Max',
                 'version'=>'1.0');
?>