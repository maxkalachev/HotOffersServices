<?php
    return array(
        'dbhost'=>'localhost',
        'dbname'=>'maxkalache_hotoffers',
    );
?>
